/**
 * Animations et effets UI
 * Gestion des boutons, animations de chargement, info-bulles, surbrillance des tableaux, bouton retour en haut, et autres interactions UI.
 * 
 * Auteur : Pierre Lefloic
 * Date de création : 2025-09-29
 * Date de dernière modification : 2025-09-29
 */

// Initialize animations when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  initializeAnimations();
});

function initializeAnimations() {
  setupSimulationButton();
  setupTooltips();
  setupTableHighlighting();
  setupBackToTop();
  setupInstructionsToggle();
  setupEconomicToggle();
  setupVisitorCounter();
}

/**
 * Set up simulation button and loading animations
 */
function setupSimulationButton() {
  const launchButton = document.getElementById('launchSimulation');
  const launchButtonMobile = document.getElementById('launchSimulation-mobile');
  const resultsSection = document.querySelector('.results-section');
  const resultsTable = document.querySelector('.results-table');
  const summaryTable = document.querySelector('.summary-table');
  
  if (!resultsSection) return;
  
  // Bind event listener to desktop button if it exists
  if (launchButton) {
    launchButton.addEventListener('click', function() {
      startSimulationFlow();
    });
  }
  
  // Bind event listener to mobile button if it exists
  if (launchButtonMobile) {
    launchButtonMobile.addEventListener('click', function() {
      startSimulationFlow();
    });
  }
  
  function startSimulationFlow() {
    // Show results section immediately but hide all content
    resultsSection.classList.add('visible');
    
    // Hide all content in results section immediately
    const resultContainers = resultsSection.querySelectorAll('.results-container');
    resultContainers.forEach(container => {
      container.style.display = 'none';
    });
    
    // Create and show blue loading curtain immediately to avoid white flash
    const existingLoader = resultsSection.querySelector('.blue-loading-curtain');
    if (existingLoader) {
      existingLoader.remove();
    }
    
    const blueCurtain = document.createElement('div');
    blueCurtain.className = 'blue-loading-curtain';
    blueCurtain.innerHTML = `
      <div class="loading-spinner"></div>
      <p class="loading-text">${translations[currentLanguage].simulationInProgress}</p>
    `;
    resultsSection.appendChild(blueCurtain);
    
    // Disable button during simulation
    if (launchButton) {
      launchButton.disabled = true;
      launchButton.textContent = translations[currentLanguage].simulationInProgress;
    }
    if (launchButtonMobile) {
      launchButtonMobile.disabled = true;
      launchButtonMobile.textContent = translations[currentLanguage].simulationInProgress;
    }
    
    // Start scroll animation
    animateScrollToResults(resultsSection, () => {
      startSimulation(blueCurtain, resultContainers);
    });
  }
  
  function animateScrollToResults(targetSection, callback) {
    const startPosition = window.pageYOffset;
    const targetPosition = targetSection.offsetTop;
    const distance = targetPosition - startPosition;
    const duration = 1000; // 1 second
    let start = null;
    
    function smoothScroll(timestamp) {
      if (!start) start = timestamp;
      const progress = timestamp - start;
      const percentage = Math.min(progress / duration, 1);
      
      // Easing function for smooth animation
      const ease = percentage < 0.5 
        ? 2 * percentage * percentage 
        : 1 - Math.pow(-2 * percentage + 2, 2) / 2;
      
      window.scrollTo(0, startPosition + (distance * ease));
      
      if (progress < duration) {
        requestAnimationFrame(smoothScroll);
      } else {
        callback();
      }
    }
    
    requestAnimationFrame(smoothScroll);
  }
  
  function startSimulation(blueCurtain, resultContainers) {
    // Start simulation after scrolling completes
    setTimeout(function() {
      // First, fade out the spinner and text immediately
      blueCurtain.classList.add('fade-spinner');
      
      // After spinner fades out, THEN make the layout changes
      setTimeout(function() {
        // Now show content containers and prepare tables (this causes the shift)
        resultContainers.forEach(container => {
          container.style.display = 'block';
        });
        
        // Populate results
        // TODO: Replace this with actual simulation results
        console.log('Simulation completed - results would be populated here');
        
        // Prepare tables for animation
        if (resultsTable) {
          resultsTable.classList.add('fade-in');
          resultsTable.classList.remove('show');
        }
        
        if (summaryTable) {
          summaryTable.classList.add('fade-in');
          summaryTable.classList.remove('show');
        }
        
        // Small delay to ensure DOM changes are complete, then start curtain animation
        setTimeout(function() {
          blueCurtain.classList.add('wipe-down');
          
          // Start smooth scroll at the same time as curtain animation
          setTimeout(function() {
            animateScrollToCenter();
          }, 100); // Small delay to let curtain start moving
          
          // After curtain animation, show the results
          setTimeout(function() {
            if (resultsTable) {
              resultsTable.classList.remove('fade-in');
              resultsTable.classList.add('show');
            }
            
            if (summaryTable) {
              summaryTable.classList.remove('fade-in');
              summaryTable.classList.add('show');
            }
            
            // Remove the blue curtain after animation completes
            setTimeout(function() {
              blueCurtain.remove();
            }, 500);
          }, 800); // Wait for curtain animation
        }, 100); // Small delay for DOM updates
      }, 500); // Wait for spinner fade-out
      
      // Re-enable button
      if (launchButton) {
        launchButton.disabled = false;
        launchButton.textContent = translations[currentLanguage].launchSimulation;
      }
      if (launchButtonMobile) {
        launchButtonMobile.disabled = false;
        launchButtonMobile.textContent = translations[currentLanguage].launchSimulation;
      }
    }, 3000); // 3 second delay to demonstrate loading
  }
  
  function animateScrollToCenter() {
    const resultsSection = document.querySelector('.results-section');
    if (resultsSection) {
      const rect = resultsSection.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      const sectionHeight = rect.height;
      
      // Calculate scroll to center the results section
      const startPosition = window.scrollY;
      const targetScroll = startPosition + rect.top - (viewportHeight - sectionHeight) / 2;
      const finalTarget = Math.max(0, targetScroll - 200); // Offset by 200px for better positioning
      const distance = finalTarget - startPosition;
      
      // Only scroll if there's a significant distance
      if (Math.abs(distance) > 50) {
        const duration = 800; // 0.8 seconds
        let start = null;
        
        function smoothScrollToResults(timestamp) {
          if (!start) start = timestamp;
          const progress = timestamp - start;
          const percentage = Math.min(progress / duration, 1);
          
          // Easing function for smooth animation
          const ease = percentage < 0.5 
            ? 2 * percentage * percentage 
            : 1 - Math.pow(-2 * percentage + 2, 2) / 2;
          
          window.scrollTo(0, startPosition + (distance * ease));
          
          if (progress < duration) {
            requestAnimationFrame(smoothScrollToResults);
          }
        }
        
        requestAnimationFrame(smoothScrollToResults);
      }
    }
  }
}

/**
 * Set up custom tooltip functionality
 */
function setupTooltips() {
  // Create tooltip element
  const tooltip = document.createElement('div');
  tooltip.className = 'custom-tooltip';
  document.body.appendChild(tooltip);
  
  // Detect if this is primarily a touch device (mobile/tablet)
  const isPrimaryTouch = (function() {
    // Check for touch support and small screen size to identify mobile/tablet
    const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    const isSmallScreen = window.innerWidth <= 768;
    return hasTouch && isSmallScreen;
  })();
  
  // Add event listeners to all elements with data-tooltip attributes
  const elementsWithTooltips = document.querySelectorAll('.results-header[data-tooltip], label[data-tooltip], .salary-grid strong[data-tooltip], .salary-grid p[data-tooltip]');
  
  elementsWithTooltips.forEach(element => {
    if (isPrimaryTouch) {
      // Mobile/Tablet: Use tap to toggle tooltips
      element.addEventListener('touchstart', function(e) {
        e.preventDefault(); // Prevent default touch behavior
        
        if (tooltip.classList.contains('show') && tooltip.currentElement === this) {
          // If tooltip is already showing for this element, hide it
          hideTooltip(tooltip);
        } else {
          // Show tooltip for this element
          showTooltip(this, tooltip);
          tooltip.currentElement = this; // Track which element is showing tooltip
        }
      });
    } else {
      // Desktop/Laptop: Use hover behavior (including touch-enabled laptops)
      element.addEventListener('mouseenter', function(e) {
        showTooltip(this, tooltip);
      });
      
      element.addEventListener('mouseleave', function() {
        hideTooltip(tooltip);
      });
      
      // Also add touch support for hybrid devices (touch laptops)
      element.addEventListener('touchstart', function(e) {
        if (tooltip.classList.contains('show') && tooltip.currentElement === this) {
          hideTooltip(tooltip);
        } else {
          showTooltip(this, tooltip);
          tooltip.currentElement = this;
        }
      });
    }
  });
  
  // Also handle elements that get tooltips added dynamically
  const headersWithTitles = document.querySelectorAll('.results-header[title]');
  headersWithTitles.forEach(header => {
    // Store the title content and remove the title attribute to prevent default tooltip
    const titleContent = header.getAttribute('title');
    header.removeAttribute('title');
    header.setAttribute('data-tooltip', titleContent);
    
    if (isPrimaryTouch) {
      // Mobile/Tablet: Use tap to toggle tooltips
      header.addEventListener('touchstart', function(e) {
        e.preventDefault();
        
        if (tooltip.classList.contains('show') && tooltip.currentElement === this) {
          hideTooltip(tooltip);
        } else {
          showTooltip(this, tooltip);
          tooltip.currentElement = this;
        }
      });
    } else {
      // Desktop/Laptop: Use hover behavior
      header.addEventListener('mouseenter', function(e) {
        showTooltip(this, tooltip);
      });
      
      header.addEventListener('mouseleave', function() {
        hideTooltip(tooltip);
      });
      
      // Also add touch support for hybrid devices
      header.addEventListener('touchstart', function(e) {
        if (tooltip.classList.contains('show') && tooltip.currentElement === this) {
          hideTooltip(tooltip);
        } else {
          showTooltip(this, tooltip);
          tooltip.currentElement = this;
        }
      });
    }
  });
  
  // Hide tooltips when scrolling (for both desktop and mobile)
  window.addEventListener('scroll', function() {
    if (tooltip.classList.contains('show')) {
      hideTooltip(tooltip);
    }
  }, { passive: true });
  
  // Hide tooltips when tapping elsewhere (for all devices)
  document.addEventListener('touchstart', function(e) {
    // Check if the tap is outside any tooltip-enabled element
    const isTooltipElement = e.target.closest('[data-tooltip]');
    if (!isTooltipElement && tooltip.classList.contains('show')) {
      hideTooltip(tooltip);
    }
  });
  
  // Hide tooltips when clicking elsewhere on desktop
  document.addEventListener('click', function(e) {
    // Check if the click is outside any tooltip-enabled element
    const isTooltipElement = e.target.closest('[data-tooltip]');
    if (!isTooltipElement && tooltip.classList.contains('show')) {
      hideTooltip(tooltip);
    }
  });
  
  function showTooltip(element, tooltip) {
    const title = element.getAttribute('data-tooltip');
    tooltip.textContent = title;
    tooltip.classList.add('show');
    
    // Position tooltip
    const rect = element.getBoundingClientRect();
    const tooltipRect = tooltip.getBoundingClientRect();
    
    // Get the actual tooltip width from CSS instead of hardcoding
    const tooltipWidth = tooltipRect.width || 280; // fallback to 280 if measurement fails
    
    // Calculate ideal centered position
    const idealLeft = rect.left + (rect.width / 2) - (tooltipWidth / 2);
    let top = rect.top - tooltipRect.height - 15;
    
    // Store the element center position
    const elementCenter = rect.left + (rect.width / 2);
    
    // Use symmetric logic for both left and right sides with actual tooltip width
    let actualLeft = idealLeft;
    if (actualLeft < 10) {
      actualLeft = 10;
    }
    if (actualLeft + tooltipWidth > window.innerWidth - 10) {
      actualLeft = window.innerWidth - tooltipWidth - 10;
    }
    
    // Position below if no space above
    let showBelow = false;
    if (top < 10) {
      top = rect.bottom + 15;
      showBelow = true;
    }
    
    tooltip.style.left = actualLeft + 'px';
    tooltip.style.top = top + 'px';
    
    // Calculate arrow position relative to element center and final tooltip position
    const arrowLeft = elementCenter - actualLeft;
    
    // Clamp arrow position to stay within tooltip bounds (20px margins from edges)
    const clampedArrowLeft = Math.max(20, Math.min(tooltipWidth - 20, arrowLeft));
    
    // Update arrow position
    const existingArrow = tooltip.querySelector('.tooltip-arrow');
    if (existingArrow) {
      existingArrow.remove();
    }
    
    const arrow = document.createElement('div');
    arrow.className = 'tooltip-arrow';
    arrow.style.position = 'absolute';
    arrow.style.left = clampedArrowLeft + 'px';
    arrow.style.transform = 'translateX(-50%)';
    arrow.style.border = '8px solid transparent';
    
    if (showBelow) {
      arrow.style.top = '-16px';
      arrow.style.borderBottomColor = '#2c3e50';
    } else {
      arrow.style.bottom = '-16px';
      arrow.style.borderTopColor = '#2c3e50';
    }
    
    tooltip.appendChild(arrow);
  }
  
  function hideTooltip(tooltip) {
    tooltip.classList.remove('show');
    tooltip.currentElement = null; // Clear the tracked element
  }
}

/**
 * Set up table row/column highlighting
 */
function setupTableHighlighting() {
  function addTableHoverEffects() {
    const resultsTable = document.querySelector('.results-table');
    if (!resultsTable) return;
    
    // Add mousemove listener to the entire table container
    resultsTable.addEventListener('mousemove', function(e) {
      handleTableHover(e);
    });
    
    resultsTable.addEventListener('mouseleave', function() {
      clearHighlights();
    });
  }
  
  function handleTableHover(e) {
    const resultsTable = e.currentTarget;
    const rect = resultsTable.getBoundingClientRect();
    const allCells = Array.from(resultsTable.children);
    
    // Calculate mouse position relative to table
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    // Find the closest cell based on mouse position
    let closestCell = null;
    let closestDistance = Infinity;
    let closestIndex = -1;
    
    allCells.forEach((cell, index) => {
      const cellRect = cell.getBoundingClientRect();
      const cellX = cellRect.left - rect.left + cellRect.width / 2;
      const cellY = cellRect.top - rect.top + cellRect.height / 2;
      
      const distance = Math.sqrt(Math.pow(mouseX - cellX, 2) + Math.pow(mouseY - cellY, 2));
      
      if (distance < closestDistance) {
        closestDistance = distance;
        closestCell = cell;
        closestIndex = index;
      }
    });
    
    if (closestCell) {
      highlightRowAndColumn(closestIndex, allCells);
    }
  }
  
  function highlightRowAndColumn(cellIndex, allCells) {
    const totalColumns = 6;
    
    // Find the actual data start (skip the spanning header row)
    let dataStartIndex = 0;
    
    // Look for the main header row (starts with "Âge")
    for (let i = 0; i < allCells.length; i++) {
      if (allCells[i].textContent.trim() === translations[currentLanguage].age) {
        dataStartIndex = i;
        break;
      }
    }
    
    // If we're in the spanning header area, use different logic
    if (cellIndex < dataStartIndex) {
      // Just highlight the current cell for spanning headers, but no intersection highlight
      clearHighlights();
      // Don't add any highlighting for the "Prestation annuelle" row
      return;
    }
    
    // Calculate row and column relative to the main data area
    const relativeIndex = cellIndex - dataStartIndex;
    const currentRow = Math.floor(relativeIndex / totalColumns);
    const currentCol = relativeIndex % totalColumns;
    const isHeaderRow = currentRow === 0; // Check if we're on the column headers row
    
    clearHighlights();
    
    // Highlight cells in the main data area
    for (let i = dataStartIndex; i < allCells.length; i++) {
      const relIdx = i - dataStartIndex;
      const cellRow = Math.floor(relIdx / totalColumns);
      const cellCol = relIdx % totalColumns;
      
      // Check if this is the intersection (hovered cell)
      const isIntersection = cellRow === currentRow && cellCol === currentCol;
      
      if (isIntersection && !isHeaderRow) {
        // Only add intersection class for data cells, not for column headers
        allCells[i].classList.add('highlight-intersection');
      } else {
        // Add row/column highlights for other cells
        if (cellRow === currentRow && !isHeaderRow) {
          allCells[i].classList.add('highlight-row');
        }
        if (cellCol === currentCol) {
          allCells[i].classList.add('highlight-col');
        }
      }
    }
    
    // Always highlight the column header when hovering anywhere in that column
    const headerIndex = dataStartIndex + currentCol;
    if (headerIndex < allCells.length) {
      allCells[headerIndex].classList.add('highlight-col');
    }
  }
  
  function clearHighlights() {
    const allCells = document.querySelectorAll('.results-cell, .results-header');
    allCells.forEach(cell => {
      cell.classList.remove('highlight-row', 'highlight-col', 'highlight-intersection');
    });
  }
  
  // Initialize hover effects
  addTableHoverEffects();
  
  // Re-add hover effects after table is updated
  const originalUpdateTable = window.TRICalculator?.prototype?.updateResultsTable;
  if (originalUpdateTable) {
    window.TRICalculator.prototype.updateResultsTable = function(results) {
      originalUpdateTable.call(this, results);
      setTimeout(addTableHoverEffects, 100); // Small delay to ensure DOM is updated
    };
  }
}

/**
 * Set up back-to-top button functionality
 */
function setupBackToTop() {
  const backToTopBtn = document.getElementById('backToTop');
  if (!backToTopBtn) return;
  
  // Show/hide button based on scroll position
  window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
      backToTopBtn.classList.remove('hidden');
    } else {
      backToTopBtn.classList.add('hidden');
    }
  });
  
  // Smooth scroll to top when clicked
  backToTopBtn.addEventListener('click', function() {
    animateScrollToTop();
  });
  
  function animateScrollToTop() {
    const startPosition = window.pageYOffset;
    const duration = 800; // 0.8 seconds
    let start = null;
    
    function smoothScrollToTop(timestamp) {
      if (!start) start = timestamp;
      const progress = timestamp - start;
      const percentage = Math.min(progress / duration, 1);
      
      // Easing function for smooth animation
      const ease = percentage < 0.5 
        ? 2 * percentage * percentage 
        : 1 - Math.pow(-2 * percentage + 2, 2) / 2;
      
      window.scrollTo(0, startPosition * (1 - ease));
      
      if (progress < duration) {
        requestAnimationFrame(smoothScrollToTop);
      }
    }
    
    requestAnimationFrame(smoothScrollToTop);
  }
}

// Add global escape and enter key handlers to unfocus elements
document.addEventListener('keydown', function(event) {
  if (event.key === 'Escape' || event.key === 'Enter') {
    // Remove focus from currently focused element
    if (document.activeElement && document.activeElement !== document.body) {
      document.activeElement.blur();
    }
  }
  
  // Add Excel-like navigation for salary inputs with up/down arrows
  if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
    const activeElement = document.activeElement;
    
    // Check if we're in a salary input field
    if (activeElement && activeElement.id && activeElement.id.startsWith('salary_')) {
      // Always prevent default behavior for arrow keys in salary inputs
      event.preventDefault();
      
      const currentAge = parseInt(activeElement.id.replace('salary_', ''));
      let targetAge;
      
      if (event.key === 'ArrowUp') {
        targetAge = currentAge - 1;
      } else if (event.key === 'ArrowDown') {
        targetAge = currentAge + 1;
      }
      
      // Check if target input exists and is not disabled
      const targetInput = document.getElementById(`salary_${targetAge}`);
      if (targetInput && !targetInput.disabled) {
        targetInput.focus();
        targetInput.select(); // Select all text for easy replacement, like Excel
      }
      // If no valid target, do nothing (stay in current field without changing value)
    }
  }
});

// Add auto-blur functionality for dropdown menus when selection changes
document.addEventListener('change', function(event) {
  // Check if the changed element is a select dropdown
  if (event.target && event.target.tagName === 'SELECT') {
    // Blur the select element after a short delay to allow the change to process
    setTimeout(function() {
      event.target.blur();
    }, 50);
  }
});

/**
 * Set up instructions toggle functionality
 */
function setupInstructionsToggle() {
  const toggle = document.getElementById('instructionsToggle');
  const content = document.getElementById('instructionsContent');
  const arrow = toggle?.querySelector('.toggle-arrow');
  
  if (!toggle || !content || !arrow) return;
  
  // Set initial state (collapsed)
  content.classList.remove('expanded');
  arrow.classList.remove('expanded');
  
  // Detect if this is a touch device
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  
  toggle.addEventListener('click', function() {
    const isExpanded = content.classList.contains('expanded');
    
    // Add tap animation on touch devices
    if (isTouchDevice) {
      toggle.classList.add('tap-animate');
      
      // Remove the animation after a short duration
      setTimeout(() => {
        toggle.classList.remove('tap-animate');
      }, 200);
    }
    
    if (isExpanded) {
      // Collapse
      content.classList.remove('expanded');
      arrow.classList.remove('expanded');
      toggle.classList.remove('expanded');
    } else {
      // Expand
      content.classList.add('expanded');
      arrow.classList.add('expanded');
      toggle.classList.add('expanded');
    }
  });
}

/**
 * Set up economic parameters toggle functionality
 */
function setupEconomicToggle() {
  const toggle = document.getElementById('economicToggle');
  const content = document.getElementById('economicContent');
  const arrow = toggle?.querySelector('.toggle-arrow');
  
  if (!toggle || !content || !arrow) return;
  
  // Set initial state (collapsed)
  content.classList.remove('expanded');
  arrow.classList.remove('expanded');
  
  // Detect if this is a touch device
  const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  
  toggle.addEventListener('click', function() {
    const isExpanded = content.classList.contains('expanded');
    
    // Add tap animation on touch devices
    if (isTouchDevice) {
      toggle.classList.add('tap-animate');
      
      // Remove the animation after a short duration
      setTimeout(() => {
        toggle.classList.remove('tap-animate');
      }, 200);
    }
    
    if (isExpanded) {
      // Collapse
      content.classList.remove('expanded');
      arrow.classList.remove('expanded');
      toggle.classList.remove('expanded');
    } else {
      // Expand
      content.classList.add('expanded');
      arrow.classList.add('expanded');
      toggle.classList.add('expanded');
    }
  });
}

/**
 * Set up visitor counter easter egg
 * Shows visitor counter when -123456789 is entered in first salary input
 */
function setupVisitorCounter() {
  const firstSalaryInput = document.getElementById('salary_17');
  const visitorCounter = document.getElementById('visitor-counter');
  
  if (!firstSalaryInput || !visitorCounter) return;
  
  // Track if visitor counter is currently shown
  let visitorCounterShown = false;
  
  firstSalaryInput.addEventListener('input', function() {
    const value = this.value;
    
    // Check if the magic number is entered
    if (value === '-123456789') {
      if (!visitorCounterShown) {
        // Show the visitor counter with animation
        visitorCounter.classList.remove('hidden');
        visitorCounterShown = true;
      }
    }
  });
}
